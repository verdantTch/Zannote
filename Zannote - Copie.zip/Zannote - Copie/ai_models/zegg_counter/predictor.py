# -*- coding: utf-8 -*-
"""
Created on Tue Jun 30 16:49:15 2026

@author: hugoz
"""

import torch
import cv2

# Mettre des . en fonction du niveau de la racine
from ai_models.zegg_counter.model import EggUNet
from ai_models.zegg_counter.Redim_image import resize_and_pad
from ai_models.zegg_counter.post_processing import detect_peaks
from ai_models.zegg_counter.post_processing import restore_points
from ai_models.zegg_counter.summary_manager import save_zannote_csv, update_summary
from ai_models.zegg_counter.config import PEAK_THRESHOLD, PEAK_MIN_DISTANCE

from pathlib import Path



class Predictor:

    def __init__(
        self,
        model_path,
        device
    ):

        self.device = device
        self.model = EggUNet()
        self.model.load_state_dict(
            torch.load(
                model_path,
                map_location=device
            )
        )

        self.model.to(device)

        self.model.eval()
        
    def preprocess(
        self,
        image_path
    ):
    
        image = cv2.imread(
            str(image_path)
        )
        
        # Afficher une erreur si l'image n'est pas lue 
        if image is None:
            raise FileNotFoundError(image_path)
            
        height, width = image.shape[:2]
        image = cv2.cvtColor(
            image,
            cv2.COLOR_BGR2RGB
        )
    
        image, scale, left, top = (
            resize_and_pad(image)
        )
    
        image = (
            torch.tensor(
                image,
                dtype=torch.float32
            )
            .permute(2, 0, 1)
            / 255.0
        )
    
        image = image.unsqueeze(0)
    
        return (
            image.to(self.device),
            scale,
            left,
            top,
            width,
            height
        )
    

    def predict_folder(
        self,
        image_folder,
        output_folder,
        threshold=PEAK_THRESHOLD,
        min_distance=PEAK_MIN_DISTANCE,
        progress_callback=None
    ):
    
        image_folder = Path(image_folder)
        output_folder = Path(output_folder)
    
        output_folder.mkdir(
            parents=True,
            exist_ok=True
        )
    
        images = []
    
        for ext in (
            "*.jpg",
            "*.jpeg",
            "*.png",
            "*.bmp",
            "*.tif",
            "*.tiff"
        ):
            images.extend(image_folder.glob(ext))
        images = sorted(images)
        
        for i, image in enumerate(images):
        
            points = self.predict_points(
                image,
                threshold,
                min_distance
            )
        
            save_zannote_csv(
                image,
                points,
                output_folder
            )
            
        
            if progress_callback is not None:
                progress_callback(i + 1, len(images))
            
        update_summary(
            output_folder,   # label_folder : où sont les CSV
            image_folder      # destination_folder : où écrire Summary.xlsx
        )
                    
        return len(images)


        
    def predict_points(
        self,
        image_path,
        threshold=0.5,
        min_distance=8
    ):
    
        (
            heatmap,
            scale,
            left,
            top,
            width,
            height
        ) = self.predict_heatmap(image_path)
    
        points = detect_peaks(
            heatmap,
            threshold,
            min_distance
        )
    
        points = restore_points(
            points,
            scale,
            left,
            top,
            width,
            height
        )
    
        return points

    def predict_heatmap(
        self,
        image_path
    ):
    
        image, scale, left, top, width, height = self.preprocess(image_path)
    
        with torch.no_grad():
    
            output = self.model(
                image
            )
    
            heatmap = torch.sigmoid(
                output
            )
    
        return (
            heatmap.cpu().numpy()[0,0],
            scale,
            left,
            top,
            width,
            height
        )