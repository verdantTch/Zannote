# -*- coding: utf-8 -*-
"""
Created on Tue Jun 23 10:05:02 2026

@author: hugoz
"""
import torch
import torch.nn as nn
import logging
import glob
import os

from evaluate import evaluate_model
from model import BCEDiceLoss
from torch.utils.tensorboard import SummaryWriter
from tqdm.auto import tqdm
from config import (
    BATCH_SIZE, 
    NUM_WORKERS, 
    LEARNING_RATE, 
    N_EPOCHS, 
    GRADIENT_CLIPPING, 
    AUG2_PATIENCE, 
    TRAIN_SPLIT, 
    VAL_SPLIT, 
    PEAK_THRESHOLD, 
    PEAK_MIN_DISTANCE,
    EARLY_STOPPING_PATIENCE,
    WEIGHT_DECAY,
    BCE_WEIGHT,
    DICE_WEIGHT
    )
from version_manager import (
    VersionManager
)
from augmentations import (
    get_phase1_transform,
    get_phase2_transform
)

from datetime import datetime

from torch.utils.data import DataLoader
 

class Trainer:
    def __init__(
        self,
        model,
        train_dataset,
        val_dataset,
        device
    ):
        self.device = device
        
        # Pour sauvegarde des messages de progression de l'entraînement 
        self.logger = logging.getLogger("Trainer")
        self.logger.setLevel(logging.INFO)

        self.scaler = torch.amp.GradScaler(
            "cuda",
            enabled=(self.device.type == "cuda") # enabled permet de ne rien changer en cas d'entraînement sur CPU
        )
        
        self.model = model.to(device)
        self.best_loss = float("inf")
        self.best_median_relative_error= float("inf")
        self.train_loader = DataLoader(
        
            train_dataset,
        
            batch_size=BATCH_SIZE,
        
            shuffle=True,
        
            num_workers=NUM_WORKERS
        
        )
        self.val_loader = DataLoader(

            val_dataset,
        
            batch_size=BATCH_SIZE,
        
            shuffle=False,
        
            num_workers=NUM_WORKERS
        
        )
        self.criterion = (
            BCEDiceLoss(
                bce_weight=BCE_WEIGHT,
                dice_weight=DICE_WEIGHT
            )
            )
        
        self.optimizer = torch.optim.AdamW(
            self.model.parameters(),
            lr=LEARNING_RATE,
            weight_decay= WEIGHT_DECAY  # à ajuster, 1e-5 à 1e-3 selon l'overfitting observé
        )
        
        self.scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
            optimizer=self.optimizer,
            mode="min",      # on minimise la loss
            factor=0.2,      # LR = LR × 0.5
            patience=4,      # attendre 5 epochs
            threshold=1e-3,  # amélioration minimale
            min_lr=1e-7      # ne jamais descendre sous cette valeur
        )
        
        # Early stopping si pas d'amélioration
        self.early_stopping_patience = EARLY_STOPPING_PATIENCE
        self.epochs_without_improvement = 0
        
        self.phase2_started = False
        self.epochs_without_improvement_aug2 = 0
        print(f"Device : {device}")
        if device.type == "cuda":
            print(torch.cuda.get_device_name(0))
            

            
    def train_epoch(self):
    
        self.model.train()
    
        running_loss = 0
    
        progress_bar = tqdm(
            self.train_loader,
            desc="Training",
            leave=False,
            unit="batch"
        )
    
        for batch in progress_bar:
    
            images = batch["image"].to(self.device)
            targets = batch["heatmap"].to(self.device)
    
            self.optimizer.zero_grad()
            
            with torch.amp.autocast(
                "cuda",
                enabled=(self.device.type == "cuda")
            ):
                outputs = self.model(images)
            
                loss = self.criterion(
                    outputs,
                    targets
                )
            
            self.scaler.scale(loss).backward()
            
            
            if GRADIENT_CLIPPING is not None:
                self.scaler.unscale_(self.optimizer)
            
                torch.nn.utils.clip_grad_norm_(
                    self.model.parameters(),
                    max_norm=GRADIENT_CLIPPING
                )
                        
            self.scaler.step(self.optimizer)
            self.scaler.update()
                
            running_loss += loss.item()
    
            progress_bar.set_postfix(
                loss=f"{loss.item():.4f}"
            )
    
        return running_loss / max(len(self.train_loader), 1)
        
    def validate(self):
    
        self.model.eval()
    
        running_loss = 0
    
        with torch.no_grad():
    
            progress_bar = tqdm(
                self.val_loader,
                desc="Validation",
                leave=False,
                unit="batch"
            )
    
            for batch in progress_bar:
    
                images = batch["image"].to(self.device)
                targets = batch["heatmap"].to(self.device)
    
                with torch.amp.autocast(
                    "cuda",
                    enabled=(self.device.type == "cuda")
                ):
                
                    outputs = self.model(images)
                
                    loss = self.criterion(
                        outputs,
                        targets
                    )
    
                running_loss += loss.item()
    
                progress_bar.set_postfix(
                    loss=f"{loss.item():.4f}"
                )
    
        return running_loss / max(len(self.val_loader), 1)
    
    def save_checkpoint(self, epoch, version_path, is_best=False):
        """Sauvegarde un checkpoint complet de l'entraînement"""
        checkpoint = {
            'epoch': epoch,
            'model_state_dict': self.model.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'scheduler_state_dict': self.scheduler.state_dict(),
            'best_loss': self.best_loss,
            'best_relative_mae': self.best_relative_mae,
            'scaler_state_dict': self.scaler.state_dict() if self.device.type == "cuda" else None,
            'epochs_without_improvement': self.epochs_without_improvement,
            'phase2_started': self.phase2_started,
            'epochs_without_improvement_aug2': self.epochs_without_improvement_aug2
        }
        
        # Sauvegarde du checkpoint principal
        checkpoint_path = version_path / f"checkpoint_epoch_{epoch+1}.pt"
        torch.save(checkpoint, checkpoint_path)
        
        # Si c'est le meilleur modèle, on le sauvegarde aussi
        if is_best:
            torch.save(checkpoint, version_path / "best_checkpoint.pt")
        
        # Garder seulement les 3 derniers checkpoints pour économiser de l'espace
        self._cleanup_old_checkpoints(version_path, keep=3)
        
        return checkpoint_path
    
    def _cleanup_old_checkpoints(self, version_path, keep=3):
        """Nettoie les anciens checkpoints pour garder seulement les N plus récents"""
        import glob
        checkpoint_files = sorted(
            glob.glob(str(version_path / "checkpoint_epoch_*.pt")),
            key=lambda x: int(x.split('_')[-1].split('.')[0])
        )
        
        # Garder seulement les 'keep' plus récents
        for old_file in checkpoint_files[:-keep]:
            try:
                import os
                os.remove(old_file)
                self.logger.info(f"Suppression du checkpoint ancien: {old_file}")
            except Exception as e:
                self.logger.warning(f"Impossible de supprimer {old_file}: {e}")
    
    def load_checkpoint(self, checkpoint_path):
        """Charge un checkpoint complet"""
        checkpoint = torch.load(
            checkpoint_path,
            map_location=self.device
        )
        
        self.epochs_without_improvement = checkpoint.get("epochs_without_improvement", 0)

        # .get(...) avec valeur par défaut pour rester compatible avec les
        # checkpoints créés avant ce changement
        self.phase2_started = checkpoint.get("phase2_started", False)
        self.epochs_without_improvement_aug2 = checkpoint.get("epochs_without_improvement_aug2", 0)
        
        
        self.model.load_state_dict(
            checkpoint["model_state_dict"]
        )
        
        self.optimizer.load_state_dict(
            checkpoint["optimizer_state_dict"]
        )
        
        self.scaler.load_state_dict(
            checkpoint["scaler_state_dict"]
        )
        
        self.scheduler.load_state_dict(
            checkpoint["scheduler_state_dict"]
        )
        
        self.best_loss = checkpoint["best_loss"]
        
        self.best_median_relative_error = checkpoint.get(
            "best_median_relative_error",
            float("inf")
        )
        if checkpoint["scaler_state_dict"] is not None and self.device.type == "cuda":
            self.scaler.load_state_dict(checkpoint["scaler_state_dict"])
        
        self.epochs_without_improvement = checkpoint.get("epochs_without_improvement", 0)
        
        epoch = checkpoint["epoch"]
        self.logger.info(f"Checkpoint chargé: epoch {epoch}")
        
        return epoch+1
    
    def load_latest_checkpoint(self, version_path):
        """Charge automatiquement le dernier checkpoint disponible"""
        import glob
        checkpoint_files = glob.glob(str(version_path / "checkpoint_epoch_*.pt"))
        
        if not checkpoint_files:
            self.logger.info("Aucun checkpoint trouvé, démarrage depuis le début")
            return 0
        
        # Trouver le checkpoint avec le numéro d'epoch le plus élevé
        latest_checkpoint = sorted(
            checkpoint_files,
            key=lambda x: int(x.split('_')[-1].split('.')[0])
        )[-1]
        
        self.logger.info(f"Chargement du checkpoint: {latest_checkpoint}")
        return self.load_checkpoint(latest_checkpoint)
    
    
    
    @staticmethod
    def find_checkpoints(version_path):
        """Trouve tous les checkpoints disponibles dans un dossier version"""
        checkpoints = []
        
        for file in glob.glob(str(version_path / "checkpoint_epoch_*.pt")):
            epoch_num = int(file.split('_')[-1].split('.')[0])
            checkpoints.append({
                'path': file,
                'epoch': epoch_num,
                'size': os.path.getsize(file) / (1024 * 1024)  # Taille en MB
            })
        
        return sorted(checkpoints, key=lambda x: x['epoch'])    
    
    
    
    def fit(
        self,
        resume_from=None
    ):
    
        best_epoch = None
        history = []
    
        version_manager = VersionManager()
    
        # --------------------------------------------------
        # Nouveau training ou reprise
        # --------------------------------------------------
    
        if resume_from is not None:
    
            version_path = resume_from.parent
    
            version_name = version_path.name
    
            start_epoch = self.load_checkpoint(
                resume_from
            )
    
            print(
                f"Reprise de {version_name}"
            )
    
        else:
    
            version_name, version_path = (
                version_manager.create_version_folder()
            )
    
            start_epoch = 0
    
            print(
                f"Nouvelle version : {version_name}"
            )
    
        print(version_path.resolve())
    
        writer = SummaryWriter(
            log_dir=version_path / "tensorboard"
        )
        writer.add_text(
            "Hyperparameters",
            f"""
        Learning rate : {LEARNING_RATE}
        Batch size : {BATCH_SIZE}
        Gradient clipping : {GRADIENT_CLIPPING}
        Aug2 patience : {AUG2_PATIENCE}
        Threshold : {PEAK_THRESHOLD}
        Min distance : {PEAK_MIN_DISTANCE}
        """,
        )
            
        # --------------------------------------------------
        # Sauvegarde métadonnées initiales
        # --------------------------------------------------
    
        version_manager.save_metadata(
            version_path,
            {
                "version": version_name,
                "date": datetime.now().isoformat(),
                "epochs_requested": N_EPOCHS,
                "start_epoch": start_epoch,
                "learning_rate": LEARNING_RATE,
                "batch_size": BATCH_SIZE,
                "aug2_patience": AUG2_PATIENCE,
                "gradient_clipping": GRADIENT_CLIPPING
            }
        )
        
        version_manager.save_split(
            version_path,
            TRAIN_SPLIT,
            VAL_SPLIT
        )
    
    
        # --------------------------------------------------
        # Boucle d'entraînement
        # --------------------------------------------------
    
        for epoch in range(start_epoch, N_EPOCHS):
        
            if not self.phase2_started:
                self.train_loader.dataset.set_transform(get_phase1_transform)
            else:
                self.train_loader.dataset.set_transform(get_phase2_transform)

            train_loss = self.train_epoch()
            val_loss = self.validate()

            # IMPORTANT : on capture le LR AVANT le scheduler.step(),
            # car celui-ci peut modifier le LR immédiatement. On veut
            # enregistrer le LR qui a réellement servi à entraîner CET
            # epoch, pas celui qui servira au suivant.
            
            current_lr = (
                self.optimizer.param_groups[0]["lr"]
            )
    
            self.scheduler.step(
                val_loss
            )
            
            
            metrics = evaluate_model(
                self.model,
                self.val_loader,
                self.device
            )
            
            median_error = metrics["median_error"]
            median_relative_error = metrics["median_relative_error"]
            mae = metrics["mae"]
            mae_std = metrics["mae_std"]
            relative_mae = metrics["relative_mae"]
            relative_mae_std = metrics["relative_mae_std"]

                        
            history.append(
            {
                "epoch": epoch + 1,
                "train_loss": train_loss,
                "val_loss": val_loss,
                "learning_rate": current_lr,
                "threshold": PEAK_THRESHOLD,
                "min_distance": PEAK_MIN_DISTANCE,
                "mae": mae,
                "mae_std": mae_std,
                "median_error": median_error,
                "median_relative_error": median_relative_error,
                "relative_mae": relative_mae,
                "relative_mae_std": relative_mae_std
            
            }
            )
    
            writer.add_scalar(
                "Loss/Train",
                train_loss,
                epoch + 1
            )
    
            writer.add_scalar(
                "Loss/Validation",
                val_loss,
                epoch + 1
            )
    
            writer.add_scalar(
                "Learning Rate",
                current_lr,
                epoch + 1
            )
            writer.add_scalar("Validation/threshold", PEAK_THRESHOLD, epoch+1)
            writer.add_scalar("Validation/min_distance", PEAK_MIN_DISTANCE, epoch+1)
            writer.add_scalar("Validation/MAE", mae, epoch+1)
            writer.add_scalar("Validation/MAE_std", mae_std, epoch+1)
            writer.add_scalar("Validation/Median_error", median_error, epoch + 1)
            writer.add_scalar("Validation/Relative_MAE", relative_mae, epoch+1)
            writer.add_scalar("Validation/Relative_MAE_std", relative_mae_std, epoch+1)
    
            message = (
                f"Epoch {epoch+1}/{N_EPOCHS}"
                f" | Train={train_loss:.4f}"
                f" | Val={val_loss:.4f}"
                f" | LR={current_lr:.2e}"
                f" | Train batches={len(self.train_loader)}"
                f" | Val batches={len(self.val_loader)}"
                f" | threshold={PEAK_THRESHOLD}"
                f" | min_distance={PEAK_MIN_DISTANCE}"
                f" | mae={mae}"
                f" | mae_std={mae_std}"
                f" | median_error={median_error}"
                f" | Relative_MAE={100*relative_mae:.2f}%"
                f" | Relative_MAE_std={100*relative_mae_std:.2f}%"
            )
    
            print(message)
    
            self.logger.info(message)
            is_best = median_relative_error < self.best_median_relative_error
            
            if is_best:
            
                self.best_loss = val_loss
                self.best_median_relative_error = median_relative_error
                best_epoch = epoch + 1
            
                self.epochs_without_improvement = 0
                self.epochs_without_improvement_aug2 = 0   # <-- ajouté
            
                version_manager.save_metrics(
                    version_path,
                    {
                        "best_val_loss": float(val_loss),
                        "best_relative_mae": float(relative_mae),
                        "threshold": float(PEAK_THRESHOLD),
                        "min_distance": float(PEAK_MIN_DISTANCE),                        
                        "median_error": float(median_error),
                        "median_relative_error": float(median_relative_error),
                        "mae": float(mae),
                        "mae_std": float(mae_std),
                        "relative_mae": float(relative_mae),
                        "relative_mae_std": float(relative_mae_std),
                        "train_loss": float(train_loss),
                        "epoch": best_epoch
                    }
                )
   
                torch.save(
                    self.model.state_dict(),
                    version_path / "best_model.pt"
                )      
                
            else:
            
                self.epochs_without_improvement += 1
                self.epochs_without_improvement_aug2 += 1   # <-- ajouté
            
                if (
                    not self.phase2_started
                    and self.epochs_without_improvement_aug2 >= AUG2_PATIENCE
                ):
                    self.phase2_started = True
            
                    print("\n===== Stagnation détectée : passage aux augmentations Phase 2 =====\n")
                    self.logger.info("Passage aux augmentations Phase 2 (stagnation)")
            
                self.logger.info(
                    f"No improvement "
                    f"{self.epochs_without_improvement}/"
                    f"{self.early_stopping_patience}"
                )
                
            # ------------------------------------------
            # Checkpoint à chaque époque
            # ------------------------------------------
    
            self.save_checkpoint(
                epoch,
                version_path,
                is_best=is_best
            )
    
            # ------------------------------------------
            # Historique
            # ------------------------------------------
    
            version_manager.save_history(
                version_path,
                history
            )
    
            # ------------------------------------------
            # Early stopping
            # ------------------------------------------
    
            if (
                self.epochs_without_improvement
                >=
                self.early_stopping_patience
            ):
    
                self.logger.info(
                    "Early stopping"
                )
    
                break
    
        # --------------------------------------------------
        # Sauvegardes finales
        # --------------------------------------------------
    
        version_manager.save_loss_curve(
            version_path,
            history,
            best_epoch
        )
    
        version_manager.save_metadata(
            version_path,
            {
                "version": version_name,
                "date": datetime.now().isoformat(),
                "epochs_requested": N_EPOCHS,
                "epochs_completed": epoch + 1,
                "best_epoch": best_epoch,
                "best_val_loss": self.best_loss,
                "threshold": PEAK_THRESHOLD,
                "min_distance": PEAK_MIN_DISTANCE,
                "best_relative_mae": self.best_relative_mae,
                "learning_rate": LEARNING_RATE,
                "batch_size": BATCH_SIZE
            }
        )
        

    
        writer.close()
    
        self.logger.info(
            f"Training terminé "
            f"(best epoch = {best_epoch})"
        )
    
        return history