# -*- coding: utf-8 -*-
"""
Created on Mon Jun 22 12:41:08 2026

@author: hugoz
"""

from PyQt6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QFileDialog
)

from PyQt6.QtGui import QIcon, QPixmap, QPainter
from PyQt6.QtCore import QSize, Qt

from managers.image_manager import ImageManager
from ui.annotation_window import AnnotationWindow
from ui.home_card import HomeCard
from utils.icons import svg_to_icon


class HomePage(QWidget):

    def __init__(self):

        super().__init__()

        self.setWindowTitle(
            "Zannote"
        )

        icon = svg_to_icon("assets/logo.svg")
        self.setWindowIcon(icon)

        self.build_ui()
        
        # Grand écran
        self.setWindowState(
            Qt.WindowState.WindowMaximized
        )

    def build_ui(self):

        main_layout = QVBoxLayout(self)
        
        # === TITRE ===
        title = QLabel("Zannote")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet("""
            font-size:48px;
            font-weight:bold;
            color:#000000;
        """)
        
        # === CARTES ===
        cards_layout = QHBoxLayout()
        cards_layout.setSpacing(120)

        annotation_card = HomeCard(
            title="Zannote",
            color="#FF0000",
            description="Annotation manuelle\net vérification",
            icon_path="assets/logo.svg",
            callback=self.open_annotation
        )

        ai_card = HomeCard(
            title="Zannote IA",
            color="#11BED5",
            description="Comptage IA\n",
            icon_path="assets/logo_IA.svg",
            callback=self.open_ai_menu
        )

        cards_layout.addStretch()
        cards_layout.addWidget(annotation_card)
        cards_layout.addWidget(ai_card)
        cards_layout.addStretch()

        # === ASSEMBLAGE ===
        # Légère marge en haut pour aérer
        main_layout.addStretch()
        main_layout.addWidget(title)
        main_layout.addSpacing(20)
        main_layout.addLayout(cards_layout)
        main_layout.addStretch()  # Pousse le contenu vers le haut

        self.setStyleSheet("""
            QWidget{
                background:#F5F5F5;
            }
        """)
        
    def open_annotation(self):
    
        folder = QFileDialog.getExistingDirectory(
            self,
            "Choisir dossier images"
        )
    
        if not folder:
            return
    
        image_manager = ImageManager()
    
        if not image_manager.contains_images(folder):
    
            QMessageBox.warning(
                self,
                "Aucune image",
                "Le dossier sélectionné ne contient aucune image."
            )
            return
    
        self.annotation_window = AnnotationWindow()
        self.annotation_window.load_folder(folder)
        self.annotation_window.show()
        self.close()
        
    def open_ai_menu(self):
        from ui.ai_menu import AIMenu
        self.ai_menu = AIMenu()
        self.ai_menu.show()
        self.close()